// icons.jsx — SVG icon components
// Stroke-based, 1.5 weight, geometric.

const Icon = ({ d, children, size = 16, ...rest }) => (
  <svg viewBox="0 0 24 24" width={size} height={size} fill="none"
       stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...rest}>
    {d ? <path d={d} /> : children}
  </svg>
);
const IcoChat = (p) => (
  <Icon {...p}>
    <path d="M4 5h16v10H8l-4 4z" />
    <path d="M9 9h6M9 12h4" />
  </Icon>
);
const IcoAgent = (p) => (
  <Icon {...p}>
    <rect x="4" y="6" width="16" height="12" rx="2.5" />
    <path d="M12 3v3" />
    <circle cx="9" cy="12" r="1.2" />
    <circle cx="15" cy="12" r="1.2" />
    <path d="M9.5 15.5h5" />
  </Icon>
);
const IcoModel = (p) => (
  <Icon {...p}>
    <path d="M12 3 4 7v10l8 4 8-4V7z" />
    <path d="M4 7l8 4 8-4M12 11v10" />
  </Icon>
);
const IcoMemory = (p) => (
  <Icon {...p}>
    <ellipse cx="12" cy="6" rx="8" ry="3" />
    <path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6" />
    <path d="M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6" />
  </Icon>
);
const IcoTool = (p) => (
  <Icon {...p}>
    <rect x="4" y="4" width="16" height="16" rx="2" />
    <path d="M4 9h16M9 4v16" />
  </Icon>
);
const IcoVector = (p) => (
  <Icon {...p}>
    <circle cx="6" cy="6" r="2" />
    <circle cx="18" cy="6" r="2" />
    <circle cx="6" cy="18" r="2" />
    <circle cx="18" cy="18" r="2" />
    <path d="M8 6h8M8 18h8M6 8v8M18 8v8" strokeDasharray="2 2" />
  </Icon>
);
const IcoCode = (p) => (
  <Icon {...p}>
    <path d="m8 8-4 4 4 4M16 8l4 4-4 4M14 5l-4 14" />
  </Icon>
);
const IcoIf = (p) => (
  <Icon {...p}>
    <circle cx="6" cy="6" r="2" />
    <circle cx="6" cy="18" r="2" />
    <circle cx="18" cy="12" r="2" />
    <path d="M6 8v8M8 6c6 0 8 4 8 6M8 18c6 0 8-4 8-6" />
  </Icon>
);
const IcoHttp = (p) => (
  <Icon {...p}>
    <circle cx="12" cy="12" r="9" />
    <path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" />
  </Icon>
);
const IcoSlack = (p) => (
  <Icon {...p}>
    <path d="M9 4v8M15 12v8M4 9h8M12 15h8" />
    <rect x="7" y="14" width="4" height="6" rx="2" />
    <rect x="13" y="4" width="4" height="6" rx="2" />
  </Icon>
);
const IcoWebhook = (p) => (
  <Icon {...p}>
    <circle cx="6" cy="18" r="2.5" />
    <circle cx="18" cy="18" r="2.5" />
    <circle cx="12" cy="6" r="2.5" />
    <path d="m12 8 4 8M12 8l-4 8M8.5 18h7" />
  </Icon>
);
const IcoSchedule = (p) => (
  <Icon {...p}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 7v5l3 2" />
  </Icon>
);
const IcoOutput = (p) => (
  <Icon {...p}>
    <path d="M4 12h12M12 6l6 6-6 6" />
    <path d="M20 4v16" />
  </Icon>
);
const IcoBolt = (p) => (
  <Icon {...p}>
    <path d="M13 3 4 14h7l-1 7 9-11h-7z" />
  </Icon>
);

// ui icons
const IcoSearch = (p) => (
  <Icon {...p}>
    <circle cx="11" cy="11" r="7" />
    <path d="m20 20-3.5-3.5" />
  </Icon>
);
const IcoPlus = (p) => <Icon {...p}><path d="M12 5v14M5 12h14" /></Icon>;
const IcoCheck = (p) => <Icon {...p}><path d="M4 12l5 5L20 6" /></Icon>;
const IcoClose = (p) => <Icon {...p}><path d="M6 6l12 12M18 6L6 18" /></Icon>;
const IcoPlay = (p) => <Icon {...p}><path d="M7 5v14l12-7z" /></Icon>;
const IcoSave = (p) => (
  <Icon {...p}>
    <path d="M5 4h11l3 3v13H5z" />
    <path d="M8 4v5h7V4M8 20v-6h8v6" />
  </Icon>
);
const IcoZoomIn = (p) => <Icon {...p}><path d="M12 5v14M5 12h14" /></Icon>;
const IcoZoomOut = (p) => <Icon {...p}><path d="M5 12h14" /></Icon>;
const IcoFit = (p) => (
  <Icon {...p}>
    <path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" />
  </Icon>
);
const IcoMore = (p) => (
  <Icon {...p}>
    <circle cx="6" cy="12" r="1" /><circle cx="12" cy="12" r="1" /><circle cx="18" cy="12" r="1" />
  </Icon>
);
const IcoChevron = (p) => <Icon {...p}><path d="m9 6 6 6-6 6" /></Icon>;
const IcoGrip = (p) => (
  <Icon {...p}>
    <circle cx="9" cy="6" r="1" /><circle cx="15" cy="6" r="1" />
    <circle cx="9" cy="12" r="1" /><circle cx="15" cy="12" r="1" />
    <circle cx="9" cy="18" r="1" /><circle cx="15" cy="18" r="1" />
  </Icon>
);
const IcoShare = (p) => (
  <Icon {...p}>
    <circle cx="6" cy="12" r="2.5" />
    <circle cx="18" cy="6" r="2.5" />
    <circle cx="18" cy="18" r="2.5" />
    <path d="m8 11 8-4M8 13l8 4" />
  </Icon>
);
const IcoHistory = (p) => (
  <Icon {...p}>
    <path d="M3 12a9 9 0 1 0 3-6.7L3 8M3 3v5h5M12 7v5l3 2" />
  </Icon>
);

// ─── KiAgent multi-agent icons ───────────────────────────────────────────
const IcoPM = (p) => (
  <Icon {...p}>
    <rect x="6" y="4" width="12" height="17" rx="2" />
    <path d="M9 4v2h6V4M9 11h6M9 14h6M9 17h4" />
  </Icon>
);
const IcoDebate = (p) => (
  <Icon {...p}>
    <path d="M3 6h10v7H8l-3 3v-3H3z" />
    <path d="M11 10h7v5h-3l-2 2v-2" />
  </Icon>
);
const IcoJudge = (p) => (
  <Icon {...p}>
    <path d="M7 4l10 4M5 9l4-1.5M13 6.5l4-1.5" />
    <path d="M7 9l-3 6h6zM17 7l-3 6h6z" />
    <path d="M12 8v12M8 20h8" />
  </Icon>
);
const IcoFrontend = (p) => (
  <Icon {...p}>
    <rect x="3" y="4" width="18" height="14" rx="2" />
    <path d="M3 8h18M6 6h.01M9 6h.01M12 6h.01M8 12h8M8 15h5" />
  </Icon>
);
const IcoBackend = (p) => (
  <Icon {...p}>
    <rect x="4" y="4" width="16" height="5" rx="1.5" />
    <rect x="4" y="11" width="16" height="5" rx="1.5" />
    <path d="M7 6.5h.01M7 13.5h.01M11 6.5h6M11 13.5h6M8 18v2h8v-2" />
  </Icon>
);
const IcoImprover = (p) => (
  <Icon {...p}>
    <path d="M21 12a9 9 0 1 1-3-6.7M21 4v5h-5" />
    <path d="M9 12l2 2 4-4" />
  </Icon>
);
const IcoSynth = (p) => (
  <Icon {...p}>
    <circle cx="6" cy="6" r="2" />
    <circle cx="18" cy="6" r="2" />
    <circle cx="6" cy="18" r="2" />
    <circle cx="18" cy="18" r="2" />
    <path d="M8 6c4 1 6 4 6 6M16 6c-4 1-6 4-6 6M8 18c4-1 6-4 6-6M16 18c-4-1-6-4-6-6" />
    <circle cx="12" cy="12" r="2" fill="currentColor" />
  </Icon>
);
const IcoDatabase = (p) => (
  <Icon {...p}>
    <ellipse cx="12" cy="5" rx="8" ry="2.5" />
    <path d="M4 5v6c0 1.4 3.6 2.5 8 2.5s8-1.1 8-2.5V5" />
    <path d="M4 11v6c0 1.4 3.6 2.5 8 2.5s8-1.1 8-2.5v-6" />
    <circle cx="9" cy="11" r=".5" fill="currentColor" />
    <circle cx="9" cy="17" r=".5" fill="currentColor" />
  </Icon>
);
const IcoGroq = (p) => (
  <Icon {...p}>
    <path d="M13 3 4 14h7l-1 7 9-11h-7z" />
  </Icon>
);
const IcoGemini = (p) => (
  <Icon {...p}>
    <path d="M12 3l2.5 7L21 12l-6.5 2L12 21l-2.5-7L3 12l6.5-2z" />
  </Icon>
);
const IcoMistral = (p) => (
  <Icon {...p}>
    <path d="M4 5h4v4H4zM16 5h4v4h-4zM4 11h4v4H4zM10 11h4v4h-4zM16 11h4v4h-4zM4 17h4v3H4zM16 17h4v3h-4z" />
  </Icon>
);
const IcoOpenRouter = (p) => (
  <Icon {...p}>
    <circle cx="5" cy="12" r="2.5" />
    <circle cx="19" cy="6" r="2.5" />
    <circle cx="19" cy="18" r="2.5" />
    <path d="m7 11 10-4M7 13l10 4" />
  </Icon>
);
const IcoReasoning = (p) => (
  <Icon {...p}>
    <path d="M9 4a4 4 0 0 0-3 7c-1 1-1 2 0 3-1 1-1 3 1 3 0 2 2 3 3 2v3" />
    <path d="M15 4a4 4 0 0 1 3 7c1 1 1 2 0 3 1 1 1 3-1 3 0 2-2 3-3 2v3" />
    <path d="M9 4h6" />
  </Icon>
);
const IcoStream = (p) => (
  <Icon {...p}>
    <path d="M3 8c4 0 4 8 8 8s4-8 8-8" />
    <path d="M3 13c4 0 4 8 8 8s4-8 8-8" />
    <circle cx="20" cy="6" r="1.5" fill="currentColor" />
  </Icon>
);
const IcoTrash = (p) => (
  <Icon {...p}>
    <path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6" />
  </Icon>
);

Object.assign(window, {
  IcoChat, IcoAgent, IcoModel, IcoMemory, IcoTool, IcoVector, IcoCode, IcoIf,
  IcoHttp, IcoSlack, IcoWebhook, IcoSchedule, IcoOutput, IcoBolt,
  IcoSearch, IcoPlus, IcoCheck, IcoClose, IcoPlay, IcoSave,
  IcoZoomIn, IcoZoomOut, IcoFit, IcoMore, IcoChevron, IcoGrip, IcoShare, IcoHistory,
  IcoPM, IcoDebate, IcoJudge, IcoFrontend, IcoBackend, IcoImprover, IcoSynth,
  IcoDatabase, IcoGroq, IcoGemini, IcoMistral, IcoOpenRouter, IcoReasoning, IcoStream, IcoTrash,
});
