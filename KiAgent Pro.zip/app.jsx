// app.jsx — Canvas + main app

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#22c55e",
  "grid": "dots",
  "edgeStyle": "orthogonal",
  "flowAnimation": true
} /*EDITMODE-END*/;

const ACCENT_HUES = {
  "#a78bfa": 268,
  "#22c55e": 145,
  "#6366f1": 252,
  "#f59e0b": 75,
  "#06b6d4": 195
};

// ─── Node size helpers ───────────────────────────────────────────────────
function nodeSize(node) {
  const def = NODE_TYPES[node.type];
  const w = def.isHero ? 320 : 230;
  let h = 64; // head
  if (node.chips || def.isHero) h += 32; // meta row
  if (def.isHero) h += 76; // slots row
  return { w, h };
}

// Compute anchor points for an edge.
//
// Both side AND position-along-side are dynamic when an `otherNode` is
// passed: left/right anchors slide vertically toward the partner, top/bottom
// anchors slide horizontally toward the partner. This lets multiple edges
// landing on the same side of a node spread out instead of stacking on a
// single port.
function anchorPoint(node, kind, side, otherNode) {
  const { w, h } = nodeSize(node);
  const MARGIN = 22;
  if (side === "right" || side === "left") {
    let y;
    if (otherNode) {
      const oH = nodeSize(otherNode).h;
      const oCenterY = otherNode.y + oH / 2;
      y = Math.max(node.y + MARGIN, Math.min(node.y + h - MARGIN, oCenterY));
    } else {
      y = node.y + 28;
    }
    return { x: side === "right" ? node.x + w : node.x, y };
  }
  if (side === "top" || side === "bottom") {
    let x;
    if (otherNode) {
      const oW = nodeSize(otherNode).w;
      const oCenterX = otherNode.x + oW / 2;
      x = Math.max(node.x + MARGIN, Math.min(node.x + w - MARGIN, oCenterX));
    } else {
      x = node.x + w / 2;
    }
    return { x, y: side === "top" ? node.y : node.y + h };
  }
  // slot anchor on agent (hero) — bottom of node at slot x
  if (side.startsWith("slot-")) {
    const slotOrder = { "slot-model": 0, "slot-memory": 1, "slot-tool": 2 };
    const idx = slotOrder[side];
    const slotW = (w - 24 - 20) / 3; // padding 12 each side + 2 gaps of 10
    const baseX = node.x + 12 + slotW / 2 + idx * (slotW + 10);
    return { x: baseX, y: node.y + h };
  }
  return { x: node.x + w / 2, y: node.y + h / 2 };
}

function edgePath(a, b, edgeStyle, vertical) {
  if (edgeStyle === "straight") {
    return `M ${a.x} ${a.y} L ${b.x} ${b.y}`;
  }
  if (edgeStyle === "orthogonal") {
    if (vertical) {
      // Vertical attaches: bend the L close to the target so the horizontal
      // segment lies just past the target slot, not across the source side.
      const dir = a.y > b.y ? 1 : -1;
      const midY = b.y + 30 * dir;
      return `M ${a.x} ${a.y} L ${a.x} ${midY} L ${b.x} ${midY} L ${b.x} ${b.y}`;
    }
    // Horizontal flow: fork close to source so multiple outgoing edges share
    // a visible trunk leaving the source node, then split toward each target.
    const FORK_GAP = 50;
    const midX = a.x + FORK_GAP * Math.sign(b.x - a.x || 1);
    return `M ${a.x} ${a.y} L ${midX} ${a.y} L ${midX} ${b.y} L ${b.x} ${b.y}`;
  }
  // bezier
  if (vertical) {
    const dir = a.y > b.y ? -1 : 1;
    const dy = Math.max(40, Math.abs(b.y - a.y) * 0.4);
    return `M ${a.x} ${a.y} C ${a.x} ${a.y + dy * dir}, ${b.x} ${b.y - dy * dir}, ${b.x} ${b.y}`;
  }
  const dx = Math.max(50, Math.abs(b.x - a.x) * 0.45);
  return `M ${a.x} ${a.y} C ${a.x + dx} ${a.y}, ${b.x - dx} ${b.y}, ${b.x} ${b.y}`;
}

// ─── Initial graph — KiAgent Multi-Agent Pipeline ────────────────────────
const INITIAL_NODES = [
  // Entry → PM (task sits centered above PM)
  { id: "n_task",   type: "task_received",    x: 400,  y: 40,  status: "ok",
    title: "Aufgabe empfangen", subtitle: "klick → Befehl eingeben", chips: ["goal", "lang"] },
  { id: "n_pm",     type: "project_manager",  x: 380,  y: 220, status: "ok",
    title: "Project Manager", subtitle: "orchestrator · verteilt", chips: ["plan", "fan-out", "synth"],
    slotsFilled: [true, true, true] },

  // PM verteilt → 3 Branches
  // Top branch: debate-flow
  { id: "n_debate", type: "debate",           x: 830,  y: 100, status: "ok",
    title: "Multi-Model-Debatte", subtitle: "branch · debate", chips: ["4 redner", "→ judge"] },
  { id: "n_judge",  type: "judge",            x: 1130, y: 100, status: "ok",
    title: "Architecture Judge", subtitle: "verdict", chips: ["1 verdict"] },

  // Mid branches: parallel coding
  { id: "n_fe",     type: "frontend_agent",   x: 830,  y: 260, status: "ok",
    title: "Frontend Agent", subtitle: "branch · parallel", chips: ["spec", "4 prov"] },
  { id: "n_be",     type: "backend_agent",    x: 830,  y: 420, status: "ok",
    title: "Backend Agent", subtitle: "branch · parallel", chips: ["spec", "4 prov"] },

  // Join + tail
  { id: "n_si",     type: "self_improver",    x: 1130, y: 320, status: "ok",
    title: "Self Improver", subtitle: "phase 4", chips: ["fe ✓", "be ✓", "→ mem"] },
  { id: "n_rev",    type: "review_collab",    x: 1430, y: 320, status: "ok",
    title: "Reviewer Kollaboration", subtitle: "phase 5", chips: ["combined"] },
  { id: "n_ws",     type: "ws_broadcast",     x: 1730, y: 320, status: "idle",
    title: "WebSocket /ws", subtitle: "broadcast", chips: ["stream"] },

  // Attached resources (below PM hero)
  { id: "n_groq",   type: "groq_provider",    x: 110,  y: 580, status: "ok",
    title: "Groq · Llama 3.3", subtitle: "primary · always-on", chips: ["llama-3.3", "async"], badge: "★" },
  { id: "n_mem",    type: "pgvector_memory",  x: 445,  y: 580, status: "ok",
    title: "pgvector Memory", subtitle: "memory_manager", chips: ["init", "store+search"] },
  { id: "n_synth",  type: "synthesizer",      x: 780,  y: 580, status: "ok",
    title: "Gemini Synthesizer", subtitle: "merge outputs", chips: ["gemini-2", "merge"] },

  // Available provider pool (not connected — purely visual)
  { id: "n_gemini",   type: "gemini_provider",     x: 110,  y: 880, status: "ok",
    title: "Gemini 2.0 Flash", subtitle: "GOOGLE_API_KEY",        chips: ["debate", "synth"] },
  { id: "n_mistral",  type: "mistral_provider",    x: 390,  y: 880, status: "ok",
    title: "Mistral Small",    subtitle: "MISTRAL_API_KEY",       chips: ["120t", "debate"] },
  { id: "n_or",       type: "openrouter_provider", x: 670,  y: 880, status: "ok",
    title: "OpenRouter",       subtitle: "OPENROUTER_API_KEY",    chips: ["cobuddy"] },
  { id: "n_orr",      type: "reasoning_provider",  x: 950,  y: 880, status: "idle",
    title: "OpenRouter Reasoning", subtitle: "REASONING_API_KEY", chips: ["optional"] },
];

const INITIAL_EDGES = [
  // Entry
  { id: "e1",  from: "n_task",   to: "n_pm",     kind: "main", label: "goal" },
  // PM verteilt → 3 Branches
  { id: "e2",  from: "n_pm",     to: "n_debate", kind: "main", label: "debate" },
  { id: "e3",  from: "n_pm",     to: "n_fe",     kind: "main", label: "spec" },
  { id: "e4",  from: "n_pm",     to: "n_be",     kind: "main", label: "spec" },
  // Sub-flow
  { id: "e5",  from: "n_debate", to: "n_judge",  kind: "main", label: "args" },
  // Merge FE/BE → SI
  { id: "e6",  from: "n_fe",     to: "n_si",     kind: "main", label: "fe" },
  { id: "e7",  from: "n_be",     to: "n_si",     kind: "main", label: "be" },
  // Tail
  { id: "e8",  from: "n_si",     to: "n_rev",    kind: "main", label: "eval" },
  { id: "e9",  from: "n_rev",    to: "n_ws",     kind: "main", label: "out" },
  // Judge → PM feedback (verdict)
  { id: "e10", from: "n_judge",  to: "n_pm",     kind: "main", label: "verdict" },
  // Attached resources (dashed)
  { id: "a1",  from: "n_groq",  to: "n_pm", kind: "model",  label: "prov" },
  { id: "a2",  from: "n_mem",   to: "n_pm", kind: "memory", label: "mem" },
  { id: "a3",  from: "n_synth", to: "n_pm", kind: "tool",   label: "synth" },
];

// World-space labels rendered inside the canvas world
const WORLD_LABELS = [
  { id: "wl_entry",     x: 400,  y: 10,  kind: "section", text: "EINGANG · POST /api/run" },
  { id: "wl_pipeline",  x: 110,  y: 200, kind: "section", text: "PM VERTEILT" },
  { id: "wl_resources", x: 110,  y: 500, kind: "section", text: "ATTACHED" },
  { id: "wl_pool",      x: 110,  y: 800, kind: "section", text: "PROVIDER-POOL" },
];


// ─── Edges layer ─────────────────────────────────────────────────────────
function Edges({ nodes, edges, edgeStyle, flowAnim, runningEdges, hoveredEdge, setHoveredEdge }) {
  const byId = React.useMemo(() => Object.fromEntries(nodes.map((n) => [n.id, n])), [nodes]);

  return (
    <svg className="edges" width="100%" height="100%" style={{ width: 4000, height: 3000 }}>
      <defs>
        <marker id="arrow" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6"
        orient="auto-start-reverse">
          <path d="M0 0 L8 5 L0 10 z" fill="currentColor" />
        </marker>
      </defs>

      {edges.map((e) => {
        const from = byId[e.from], to = byId[e.to];
        if (!from || !to) return null;
        const isAttach = e.kind !== "main";

        // Pick anchor sides based on relative geometry:
        // - Vertical relationship (one node clearly below the other) → bottom/top
        // - Backward (target left of source) → overhead "top/top" arc
        // - Default forward → right/left
        const fromSize = nodeSize(from), toSize = nodeSize(to);
        const horizDist = Math.max(0, to.x - (from.x + fromSize.w), from.x - (to.x + toSize.w));
        const vertDist  = Math.max(0, to.y - (from.y + fromSize.h), from.y - (to.y + toSize.h));
        const isVertical = !isAttach && vertDist > horizDist + 30;
        const isBackward = !isAttach && !isVertical && from.x > to.x;

        const fromSide = isAttach ? "top"
          : isVertical ? (to.y > from.y ? "bottom" : "top")
          : isBackward ? "top"
          : "right";
        const toSide = isAttach
          ? e.kind === "model" ? "slot-model" : e.kind === "memory" ? "slot-memory" : "slot-tool"
          : isVertical ? (to.y > from.y ? "top" : "bottom")
          : isBackward ? "top"
          : "left";

        const useDynamic = !isAttach;
        const a = anchorPoint(from, e.kind, fromSide, useDynamic ? to : null);
        const b = anchorPoint(to,   e.kind, toSide,   useDynamic ? from : null);

        let d;
        let labelX, labelY;
        if (isBackward) {
          const overheadY = Math.min(a.y, b.y) - 50;
          d = `M ${a.x} ${a.y} L ${a.x} ${overheadY} L ${b.x} ${overheadY} L ${b.x} ${b.y}`;
          labelX = (a.x + b.x) / 2;
          labelY = overheadY;
        } else if (isVertical) {
          const midY = (a.y + b.y) / 2;
          d = `M ${a.x} ${a.y} L ${a.x} ${midY} L ${b.x} ${midY} L ${b.x} ${b.y}`;
          labelX = (a.x + b.x) / 2;
          labelY = midY;
        } else {
          d = edgePath(a, b, edgeStyle, isAttach);
        }
        const isActive = runningEdges.has(e.id);

        // Label position: midpoint for bezier/straight, on the unique
        // last segment near the target for orthogonal (so parallel edges
        // out of the same source don't stack their labels).
        if (!isBackward && !isVertical) {
          if (edgeStyle === "orthogonal") {
            if (isAttach) {
              // Same midY math as edgePath — label sits on the horizontal middle segment.
              const dir = a.y > b.y ? 1 : -1;
              const midY = b.y + 30 * dir;
              labelX = (a.x + b.x) / 2;
              labelY = midY;
            } else {
              const midX = a.x + 50 * Math.sign(b.x - a.x || 1);
              labelX = (midX + b.x) / 2;
              labelY = b.y;
            }
          } else {
            labelX = (a.x + b.x) / 2;
            labelY = (a.y + b.y) / 2;
          }
        }
        const labelW = (e.label?.length || 0) * 6 + 16;

        const lineClass = [
        "edge-line",
        isAttach && "is-data",
        (isActive || hoveredEdge === e.id) && "is-active",
        flowAnim && isActive && "dash-flow"].
        filter(Boolean).join(" ");

        return (
          <g key={e.id} style={{ pointerEvents: "auto" }}
          onMouseEnter={() => setHoveredEdge(e.id)}
          onMouseLeave={() => setHoveredEdge(null)}>
            {/* invisible wider hit area */}
            <path d={d} stroke="transparent" strokeWidth="14" fill="none" />
            <path d={d} className={lineClass} />

            {/* endpoint dots — show where each line connects to a node */}
            {!isAttach && (
              <>
                <circle cx={a.x} cy={a.y} r="3.5" className={`edge-endpoint ${(isActive || hoveredEdge === e.id) ? "is-active" : ""}`} />
                <circle cx={b.x} cy={b.y} r="3.5" className={`edge-endpoint ${(isActive || hoveredEdge === e.id) ? "is-active" : ""}`} />
              </>
            )}

            {/* flowing dot for active edges */}
            {isActive && flowAnim &&
            <circle r="3" className="flow-dot">
                <animateMotion dur="1.4s" repeatCount="indefinite" path={d} />
              </circle>
            }

            {e.label &&
            <g transform={`translate(${labelX}, ${labelY})`}>
                <rect x={-labelW / 2} y={-9} width={labelW} height={18} rx={9} className="edge-label-bg" />
                <text textAnchor="middle" dominantBaseline="central" className="edge-label">{e.label}</text>
              </g>
            }
          </g>);

      })}
    </svg>);

}

// ─── Canvas ──────────────────────────────────────────────────────────────
function Canvas({ nodes, edges, selectedId, setSelectedId, onMove, onClickNode, onDoubleClickNode, onClearFloaters, popoverNodeId, tweaks, runningEdges, runningNodes }) {
  const wrapRef = React.useRef(null);
  const [view, setView] = React.useState({ x: 0, y: 0, k: 1 });
  const [panning, setPanning] = React.useState(false);
  const [dragNode, setDragNode] = React.useState(null);
  const [hoveredEdge, setHoveredEdge] = React.useState(null);

  // wheel = zoom around cursor; shift+wheel or middle-drag = pan
  React.useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const onWheel = (e) => {
      e.preventDefault();
      // Shift+wheel = pan, everything else (incl. plain wheel) = zoom around cursor
      if (e.shiftKey && !e.ctrlKey && !e.metaKey) {
        setView((v) => ({ ...v, x: v.x - e.deltaX, y: v.y - e.deltaY }));
        return;
      }
      const rect = el.getBoundingClientRect();
      const cx = e.clientX - rect.left;
      const cy = e.clientY - rect.top;
      setView((v) => {
        const delta = -e.deltaY * 0.0025;
        const k2 = Math.max(0.3, Math.min(2.2, v.k * (1 + delta)));
        const wx = (cx - v.x) / v.k;
        const wy = (cy - v.y) / v.k;
        return { k: k2, x: cx - wx * k2, y: cy - wy * k2 };
      });
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, []);

  // Pan with space-drag or background drag
  const onPointerDownBg = (e) => {
    if (e.target.closest(".node")) return;
    if (e.target.closest(".edges")) return;
    if (e.target.closest(".popover")) return;
    setSelectedId(null);
    if (onClearFloaters) onClearFloaters();
    setPanning(true);
    const start = { x: e.clientX, y: e.clientY, vx: view.x, vy: view.y };
    const onMove = (ev) => {
      setView((v) => ({ ...v, x: start.vx + (ev.clientX - start.x), y: start.vy + (ev.clientY - start.y) }));
    };
    const onUp = () => {
      setPanning(false);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  };

  const onNodePointerDown = (e, node) => {
    e.stopPropagation();
    setDragNode(node.id);
    const start = { mx: e.clientX, my: e.clientY, nx: node.x, ny: node.y, k: view.k };
    const move = (ev) => {
      const dx = (ev.clientX - start.mx) / start.k;
      const dy = (ev.clientY - start.my) / start.k;
      onMove(node.id, start.nx + dx, start.ny + dy);
    };
    const up = () => {
      setDragNode(null);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  // Fit view to nodes
  const fitView = React.useCallback(() => {
    if (!wrapRef.current || !nodes.length) return;
    const rect = wrapRef.current.getBoundingClientRect();
    let minX = Infinity,minY = Infinity,maxX = -Infinity,maxY = -Infinity;
    nodes.forEach((n) => {
      const { w, h } = nodeSize(n);
      minX = Math.min(minX, n.x);minY = Math.min(minY, n.y);
      maxX = Math.max(maxX, n.x + w);maxY = Math.max(maxY, n.y + h);
    });
    const pad = 80;
    const inspectorW = selectedId ? 340 : 0;
    const availW = Math.max(300, rect.width - inspectorW);
    const W = maxX - minX + pad * 2,H = maxY - minY + pad * 2;
    const k = Math.min(availW / W, rect.height / H, 1.4);
    setView({
      k,
      x: availW / 2 - (minX + (maxX - minX) / 2) * k,
      y: rect.height / 2 - (minY + (maxY - minY) / 2) * k
    });
  }, [nodes, selectedId]);

  React.useEffect(() => {
    // initial fit
    const t = setTimeout(fitView, 50);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const zoomBy = (factor) => setView((v) => {
    if (!wrapRef.current) return v;
    const rect = wrapRef.current.getBoundingClientRect();
    const cx = rect.width / 2,cy = rect.height / 2;
    const k2 = Math.max(0.3, Math.min(2.2, v.k * factor));
    const wx = (cx - v.x) / v.k,wy = (cy - v.y) / v.k;
    return { k: k2, x: cx - wx * k2, y: cy - wy * k2 };
  });

  const gridClass = tweaks.grid === "lines" ? "grid-lines" : tweaks.grid === "blank" ? "grid-blank" : "grid-dots";

  return (
    <div className="canvas-wrap">
      <div
        ref={wrapRef}
        className={`canvas ${panning ? "is-panning" : ""}`}
        onPointerDown={onPointerDownBg} style={{ color: "rgb(0, 0, 0)" }}>
        
        <div className={gridClass} style={{
          backgroundPosition: `${view.x}px ${view.y}px`,
          backgroundSize: `${24 * view.k}px ${24 * view.k}px`
        }} />
        <div className="canvas-vignette" />
        <div className="world" style={{ transform: `translate(${view.x}px, ${view.y}px) scale(${view.k})` }}>
          <Edges nodes={nodes} edges={edges} edgeStyle={tweaks.edgeStyle}
          flowAnim={tweaks.flowAnimation}
          runningEdges={runningEdges}
          hoveredEdge={hoveredEdge} setHoveredEdge={setHoveredEdge} />
          {WORLD_LABELS.map((l) => (
            <div key={l.id} className={`world-label world-label-${l.kind}`} style={{ left: l.x, top: l.y }}>
              {l.text}
            </div>
          ))}
          {nodes.map((n) =>
          <Node
            key={n.id}
            node={n}
            selected={selectedId === n.id}
            running={runningNodes.has(n.id)}
            onPointerDown={onNodePointerDown}
            onClick={onClickNode}
            onDoubleClick={onDoubleClickNode} />

          )}

          {/* Info popover for single-clicked nodes */}
          {popoverNodeId && (() => {
            const node = nodes.find((n) => n.id === popoverNodeId);
            if (!node) return null;
            const def = NODE_TYPES[node.type];
            if (!def) return null;
            const ns = nodeSize(node);
            return (
              <NodePopover node={node} def={def} x={node.x + ns.w + 12} y={node.y}
                           onClose={onClearFloaters}
                           onOpenFull={() => { onClearFloaters(); onDoubleClickNode && onDoubleClickNode(node.id); }} />
            );
          })()}
        </div>

        <ZoomControls zoom={view.k} onIn={() => zoomBy(1.2)} onOut={() => zoomBy(1 / 1.2)} onFit={fitView} inspectorOpen={!!selectedId} />
        <StatusBar />
      </div>
    </div>);

}

function ZoomControls({ zoom, onIn, onOut, onFit, inspectorOpen }) {
  return (
    <div className={`floating-zoom ${inspectorOpen ? "is-shifted" : ""}`}>
      <button className="fz-btn" onClick={onIn} title="Hineinzoomen"><IcoPlus /></button>
      <button className="fz-btn" onClick={onOut} title="Herauszoomen"><IcoZoomOut /></button>
      <div className="fz-pct">{Math.round(zoom * 100)}%</div>
      <button className="fz-btn" onClick={onFit} title="Einpassen"><IcoFit /></button>
    </div>);

}

function StatusBar() {
  return (
    <div className="floating-log">
      <span className="pulse" />
      <span>Letzte Ausführung</span>
      <span className="mono">vor 12 s · 1.42s · ok</span>
    </div>);

}

// ─── Small node info popover (single-click reveal) ───────────────────────
function NodePopover({ node, def, x, y, onClose, onOpenFull }) {
  const Icon = window[def.icon];
  return (
    <div className="popover" style={{ left: x, top: y }} onClick={(e) => e.stopPropagation()}>
      <div className="popover-head">
        <div className="node-icon" style={{ "--node-color": def.color, "--node-h": def.h, width: 26, height: 26 }}>
          <Icon size={14} />
        </div>
        <div className="popover-title">
          <b>{node.title || def.label}</b>
          <span>{node.subtitle || def.category.toLowerCase()}</span>
        </div>
        <button className="popover-x" onClick={onClose} title="Schließen"><IcoClose /></button>
      </div>
      <div className="popover-body">{def.description}</div>
      {node.chips && (
        <div className="popover-chips">
          {node.chips.map((c, i) => (
            <span key={i} className="popover-chip mono">{c}</span>
          ))}
        </div>
      )}
      <button className="popover-cta" onClick={onOpenFull}>
        Details öffnen
        <span className="mono" style={{ opacity: 0.6, marginLeft: 6 }}>(Doppelklick)</span>
      </button>
    </div>
  );
}

// ─── Task command input modal ────────────────────────────────────────────
function TaskInputModal({ initial = "", onSubmit, onClose }) {
  const [val, setVal] = React.useState(initial);
  const taRef = React.useRef(null);
  React.useEffect(() => { taRef.current?.focus(); taRef.current?.select(); }, []);
  const submit = () => { if (val.trim()) onSubmit(val.trim()); };
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <div>
            <b>Was soll das System tun?</b>
            <span className="mono">POST /api/run · {`{ goal, language }`}</span>
          </div>
          <button className="popover-x" onClick={onClose} title="Schließen (Esc)"><IcoClose /></button>
        </div>
        <textarea
          ref={taRef}
          className="field-input mono"
          rows={5}
          value={val}
          onChange={(e) => setVal(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); submit(); }
          }}
          placeholder="z.B. Build a REST API for a todo app with auth…"
        />
        <div className="modal-actions">
          <span className="mono" style={{ color: "var(--fg-4)", fontSize: 11 }}>
            ⌘/Ctrl + Enter zum Absenden · Esc bricht ab
          </span>
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn" onClick={onClose}>Abbrechen</button>
            <button className="btn btn-primary" onClick={submit}>Absenden</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Main App ────────────────────────────────────────────────────────────
function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [nodes, setNodes] = React.useState(INITIAL_NODES);
  const [edges, setEdges] = React.useState(INITIAL_EDGES);
  const [selectedId, setSelectedId] = React.useState(null);
  const [popoverNodeId, setPopoverNodeId] = React.useState(null);
  const [taskGoal, setTaskGoal] = React.useState("Build a REST API for a todo app with auth");
  const [taskInputOpen, setTaskInputOpen] = React.useState(false);
  const [workflowName, setWorkflowName] = React.useState("Multi-Agent · Build Pipeline");
  const [running, setRunning] = React.useState(false);
  const [runningNodes, setRunningNodes] = React.useState(new Set());
  const [runningEdges, setRunningEdges] = React.useState(new Set());

  // Apply accent hue from tweak
  React.useEffect(() => {
    const hue = ACCENT_HUES[t.accent] ?? 268;
    document.documentElement.style.setProperty("--accent-h", hue);
  }, [t.accent]);

  const onMoveNode = React.useCallback((id, x, y) => {
    setNodes((ns) => ns.map((n) => n.id === id ? { ...n, x, y } : n));
  }, []);

  const patchNode = (patch) => {
    if (!selectedId) return;
    setNodes((ns) => ns.map((n) => n.id === selectedId ? { ...n, ...patch } : n));
  };

  const deleteNode = React.useCallback((id) => {
    const targetId = id || selectedId;
    if (!targetId) return;
    setNodes((ns) => ns.filter((n) => n.id !== targetId));
    setEdges((es) => es.filter((e) => e.from !== targetId && e.to !== targetId));
    if (targetId === selectedId) setSelectedId(null);
  }, [selectedId]);

  const resetWorkflow = () => {
    setNodes(INITIAL_NODES);
    setEdges(INITIAL_EDGES);
    setSelectedId(null);
  };

  // Keyboard: Delete / Backspace to remove selected node (only when not typing in an input)
  React.useEffect(() => {
    const onKey = (e) => {
      if (e.key !== "Delete" && e.key !== "Backspace") return;
      const tag = (e.target?.tagName || "").toLowerCase();
      const editable = e.target?.isContentEditable;
      if (tag === "input" || tag === "textarea" || tag === "select" || editable) return;
      if (!selectedId) return;
      e.preventDefault();
      deleteNode(selectedId);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [selectedId, deleteNode]);

  const onClickNode = (id) => {
    if (id === "n_task") {
      setTaskInputOpen(true);
      setPopoverNodeId(null);
    } else {
      setPopoverNodeId(id);
    }
  };
  const onDoubleClickNode = (id) => {
    setPopoverNodeId(null);
    setSelectedId(id);
  };

  // ESC closes popover & modal
  React.useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") {
        setPopoverNodeId(null);
        setTaskInputOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const selected = nodes.find((n) => n.id === selectedId) || null;
  const popoverNode = nodes.find((n) => n.id === popoverNodeId) || null;

  // Run simulation: walk through the multi-agent pipeline
  const runWorkflow = async () => {
    if (running) return;
    setRunning(true);
    setRunningNodes(new Set());
    setRunningEdges(new Set());
    const seq = [
      { edges: [],         nodes: ["n_task"] },
      // PM hero — entry + attached resources light up
      { edges: ["e1", "a1", "a2", "a3"], nodes: ["n_pm", "n_groq", "n_mem", "n_synth"] },
      // PM startet Debate-Branch
      { edges: ["e2"],     nodes: ["n_debate"] },
      // Debate → Judge sub-flow
      { edges: ["e5"],     nodes: ["n_judge"] },
      // Judge → PM Verdict-Feedback
      { edges: ["e10"],    nodes: ["n_pm"] },
      // PM verteilt nach Verdict → FE/BE parallel
      { edges: ["e3", "e4"], nodes: ["n_fe", "n_be"] },
      { edges: ["e6", "e7"], nodes: ["n_si"] },
      { edges: ["e8"],     nodes: ["n_rev"] },
      { edges: ["e9"],     nodes: ["n_ws"] },
    ];
    for (const step of seq) {
      step.edges.forEach((id) => setRunningEdges((s) => new Set([...s, id])));
      await new Promise((r) => setTimeout(r, 380));
      step.nodes.forEach((id) => setRunningNodes((s) => new Set([...s, id])));
      await new Promise((r) => setTimeout(r, 460));
    }
    await new Promise((r) => setTimeout(r, 900));
    setRunningNodes(new Set());
    setRunningEdges(new Set());
    setRunning(false);
  };

  const addFromPalette = (typeId, e) => {
    // Place new node at a sensible spot (right of current bbox)
    const id = "n" + Math.random().toString(36).slice(2, 7);
    const maxX = Math.max(...nodes.map((n) => n.x));
    const newNode = {
      id, type: typeId,
      x: maxX + 280, y: 220, status: "idle",
      chips: ["neu"]
    };
    setNodes((ns) => [...ns, newNode]);
    setSelectedId(id);
  };

  return (
    <div className="app">
      <Topbar
        onRun={runWorkflow}
        isRunning={running}
        workflowName={workflowName}
        onRename={setWorkflowName} />
      
      <Sidebar onAdd={addFromPalette} />
      <Canvas
        nodes={nodes}
        edges={edges}
        selectedId={selectedId}
        setSelectedId={setSelectedId}
        onMove={onMoveNode}
        onClickNode={onClickNode}
        onDoubleClickNode={onDoubleClickNode}
        onClearFloaters={() => setPopoverNodeId(null)}
        popoverNodeId={popoverNodeId}
        tweaks={t}
        runningEdges={runningEdges}
        runningNodes={runningNodes} />
      
      <Inspector
        node={selected}
        onClose={() => setSelectedId(null)}
        onPatch={patchNode}
        onDelete={() => deleteNode()} />
      

      {taskInputOpen && (
        <TaskInputModal
          initial={taskGoal}
          onClose={() => setTaskInputOpen(false)}
          onSubmit={(goal) => {
            setTaskGoal(goal);
            setTaskInputOpen(false);
            // also reflect goal in the task node's subtitle as preview
            setNodes((ns) => ns.map((n) => n.id === "n_task" ? { ...n, subtitle: goal.length > 36 ? goal.slice(0, 36) + "…" : goal } : n));
          }}
        />
      )}

      <TweaksPanel>
        <TweakSection label="Akzent" />
        <TweakColor label="Farbe" value={t.accent}
        options={["#a78bfa", "#22c55e", "#6366f1", "#f59e0b", "#06b6d4"]}
        onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Canvas" />
        <TweakRadio label="Raster" value={t.grid}
        options={["dots", "lines", "blank"]}
        onChange={(v) => setTweak("grid", v)} />
        <TweakSelect label="Kanten-Stil" value={t.edgeStyle}
        options={[
        { value: "bezier", label: "Bezier (geschwungen)" },
        { value: "orthogonal", label: "Orthogonal (90°)" },
        { value: "straight", label: "Gerade" }]
        }
        onChange={(v) => setTweak("edgeStyle", v)} />
        <TweakToggle label="Fluss-Animation beim Ausführen" value={t.flowAnimation}
        onChange={(v) => setTweak("flowAnimation", v)} />
        <TweakSection label="Aktionen" />
        <TweakButton label="Workflow ausführen" onClick={runWorkflow} />
        <TweakButton label="Workflow zurücksetzen" onClick={resetWorkflow} />
      </TweaksPanel>
    </div>);

}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);