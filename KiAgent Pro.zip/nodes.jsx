// nodes.jsx — node type registry + Node component

// Node type catalog. Each type defines visual + behavioral metadata.
const NODE_TYPES = {
  // ─── Trigger ─────────────────────────────────────────────────────────
  task_received: {
    label: "Aufgabe empfangen", category: "Trigger",
    icon: "IcoChat", color: "oklch(75% 0.16 50)", h: 50,
    description: "POST /api/run — startet die Multi-Agent-Pipeline.",
    flair: "trigger",
  },
  chat_followup: {
    label: "Folgefrage", category: "Trigger",
    icon: "IcoChat", color: "oklch(75% 0.16 50)", h: 50,
    description: "POST /api/chat — Frage mit bisherigem Kontext.",
    flair: "trigger",
  },
  websocket_trigger: {
    label: "WebSocket-Client", category: "Trigger",
    icon: "IcoWebhook", color: "oklch(75% 0.16 50)", h: 50,
    description: "Stellt Verbindung zu /ws her und empfängt Broadcasts.",
    flair: "trigger",
  },

  // ─── Phasen ──────────────────────────────────────────────────────────
  project_manager: {
    label: "Project Manager", category: "Phasen",
    icon: "IcoPM", color: "oklch(72% 0.18 268)", h: 268,
    description: "Orchestrator — plant, koordiniert Provider, Memory & Synth.",
    isHero: true,
    slots: ["Provider*", "Memory", "Synth"],
  },
  debate: {
    label: "Multi-Model-Debatte", category: "Phasen",
    icon: "IcoDebate", color: "oklch(75% 0.13 220)", h: 220,
    description: "Phase 1 — alle Provider argumentieren reihum (Groq → Gemini → Mistral → OpenRouter).",
  },
  judge: {
    label: "Judge", category: "Phasen",
    icon: "IcoJudge", color: "oklch(75% 0.13 220)", h: 220,
    description: "Bewertet die Debatte und liefert das Verdict.",
  },
  architect_collab: {
    label: "Architect (Kollaboration)", category: "Phasen",
    icon: "IcoAgent", color: "oklch(72% 0.18 268)", h: 268,
    description: "Phase 2 — alle Provider arbeiten parallel, Gemini-Synthesizer kombiniert.",
    isHero: true,
    slots: ["Provider*", "Memory", "Synth"],
  },
  frontend_agent: {
    label: "Frontend Agent", category: "Phasen",
    icon: "IcoFrontend", color: "oklch(72% 0.16 30)", h: 30,
    description: "Phase 3 parallel — generiert Frontend-Code.",
  },
  backend_agent: {
    label: "Backend Agent", category: "Phasen",
    icon: "IcoBackend", color: "oklch(72% 0.16 30)", h: 30,
    description: "Phase 3 parallel — generiert Backend-Code.",
  },
  self_improver: {
    label: "Self Improver", category: "Phasen",
    icon: "IcoImprover", color: "oklch(75% 0.13 220)", h: 220,
    description: "Phase 4 — bewertet Outputs, speichert Erkenntnisse in pgvector.",
  },
  review_collab: {
    label: "Reviewer (Kollaboration)", category: "Phasen",
    icon: "IcoTool", color: "oklch(75% 0.13 220)", h: 220,
    description: "Phase 5 — alle Provider reviewen den Code gemeinsam.",
  },

  // ─── Provider ────────────────────────────────────────────────────────
  groq_provider: {
    label: "Groq · Llama 3.3 70B", category: "Provider",
    icon: "IcoGroq", color: "oklch(75% 0.16 50)", h: 50,
    description: "llama-3.3-70b-versatile · immer aktiv.",
    attachTo: "model",
  },
  gemini_provider: {
    label: "Gemini 2.0 Flash", category: "Provider",
    icon: "IcoGemini", color: "oklch(72% 0.16 200)", h: 200,
    description: "Google AI Studio · GOOGLE_API_KEY.",
    attachTo: "model",
  },
  mistral_provider: {
    label: "Mistral Small", category: "Provider",
    icon: "IcoMistral", color: "oklch(72% 0.18 30)", h: 30,
    description: "mistral-small-latest · MISTRAL_API_KEY.",
    attachTo: "model",
  },
  openrouter_provider: {
    label: "OpenRouter", category: "Provider",
    icon: "IcoOpenRouter", color: "oklch(72% 0.14 320)", h: 320,
    description: "baidu/cobuddy:free · OPENROUTER_API_KEY.",
    attachTo: "model",
  },
  reasoning_provider: {
    label: "OpenRouter Reasoning", category: "Provider",
    icon: "IcoReasoning", color: "oklch(70% 0.17 25)", h: 25,
    description: "Mehr Token, gründlicher · OPENROUTER_REASONING_API_KEY.",
    attachTo: "model",
  },
  synthesizer: {
    label: "Gemini Synthesizer", category: "Provider",
    icon: "IcoSynth", color: "oklch(72% 0.16 200)", h: 200,
    description: "Kombiniert die Antworten aller Provider zu einem finalen Output.",
    attachTo: "tool",
  },

  // ─── Speicher ────────────────────────────────────────────────────────
  pgvector_memory: {
    label: "pgvector Memory", category: "Speicher",
    icon: "IcoDatabase", color: "oklch(72% 0.13 160)", h: 160,
    description: "store_memory · search_memories über Agenten-Outputs.",
    attachTo: "memory",
  },

  // ─── Ausgang ─────────────────────────────────────────────────────────
  ws_broadcast: {
    label: "WebSocket-Broadcast", category: "Ausgang",
    icon: "IcoStream", color: "oklch(72% 0.14 320)", h: 320,
    description: "Sendet jede Agenten-Emission live an alle /ws-Clients.",
  },
  api_response: {
    label: "API-Antwort", category: "Ausgang",
    icon: "IcoOutput", color: "oklch(72% 0.14 320)", h: 320,
    description: "Sammelt alle Outputs und gibt sie via HTTP zurück.",
  },

  // ─── Logik (extra für Custom-Workflows) ──────────────────────────────
  if_else: {
    label: "Wenn / Dann", category: "Logik",
    icon: "IcoIf", color: "oklch(75% 0.13 220)", h: 220,
    description: "Verzweigung anhand einer Bedingung.",
  },
  code: {
    label: "Code (JS)", category: "Logik",
    icon: "IcoCode", color: "oklch(75% 0.13 220)", h: 220,
    description: "Eigene JavaScript-Logik ausführen.",
  },
};

// Sidebar groupings
const PALETTE_GROUPS = [
  { id: "trigger",  label: "Trigger",  types: ["task_received", "chat_followup", "websocket_trigger"] },
  { id: "phases",   label: "Pipeline-Phasen", types: ["project_manager", "debate", "judge", "architect_collab", "frontend_agent", "backend_agent", "self_improver", "review_collab"] },
  { id: "provider", label: "Provider", types: ["groq_provider", "gemini_provider", "mistral_provider", "openrouter_provider", "reasoning_provider", "synthesizer"] },
  { id: "storage",  label: "Speicher", types: ["pgvector_memory"] },
  { id: "output",   label: "Ausgang",  types: ["ws_broadcast", "api_response"] },
  { id: "logic",    label: "Logik",    types: ["if_else", "code"] },
];

// ─── Node render ─────────────────────────────────────────────────────────
function Node({ node, selected, onPointerDown, onClick, onDoubleClick, running }) {
  const def = NODE_TYPES[node.type];
  if (!def) return null;
  const Icon = window[def.icon];
  const isHero = !!def.isHero;
  const statusKind = node.status || "ok";

  const statusIcon = statusKind === "ok" ? <IcoCheck /> : statusKind === "err" ? <IcoClose /> : null;
  const statusClass = `node-status ${statusKind}`;

  // Distinguish single vs double click — single click fires after a short
  // delay if no second click comes in.
  const clickTimer = React.useRef(null);
  const handleClick = (e) => {
    e.stopPropagation();
    if (clickTimer.current) {
      clearTimeout(clickTimer.current);
      clickTimer.current = null;
      onDoubleClick && onDoubleClick(node.id);
    } else {
      clickTimer.current = setTimeout(() => {
        clickTimer.current = null;
        onClick && onClick(node.id);
      }, 240);
    }
  };

  const classes = [
    "node",
    isHero && "is-hero",
    selected && "is-selected",
    running && "is-running",
  ].filter(Boolean).join(" ");

  const style = {
    left: node.x,
    top: node.y,
    "--node-color": def.color,
    "--node-h": def.h,
  };

  return (
    <div
      className={classes}
      style={style}
      data-node-id={node.id}
      onPointerDown={(e) => onPointerDown(e, node)}
      onClick={handleClick}
    >
      {/* input port */}
      {!def.attachTo && def.flair !== "trigger" && (
        <div className="port in" />
      )}
      {/* output port */}
      {!def.attachTo && (
        <div className="port out" />
      )}

      <div className="node-head">
        <div className="node-icon">
          <Icon />
          {node.badge && (
            <div className="node-icon-badge">{node.badge}</div>
          )}
        </div>
        <div className="node-title">
          <b>{node.title || def.label}</b>
          <span>{node.subtitle || (isHero ? "agent · tools enabled" : def.category.toLowerCase())}</span>
        </div>
        <div className={statusClass}>{statusIcon}</div>
      </div>

      {(node.chips || isHero) && (
        <div className="node-meta">
          {(node.chips || (isHero ? ["1 input", "stream"] : [])).map((c, i) => (
            <span key={i} className={`chip${i === 0 && isHero ? " is-accent" : ""}`}>{c}</span>
          ))}
        </div>
      )}

      {isHero && (
        <div className="slots">
          {def.slots.map((s, i) => (
            <div key={i} className={`slot${node.slotsFilled?.[i] ? " is-filled" : ""}`}>
              <span className="dot" />
              {s}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

Object.assign(window, { NODE_TYPES, PALETTE_GROUPS, Node });
