// panels.jsx — Topbar, Sidebar, Inspector

function Topbar({ onRun, isRunning, workflowName, onRename }) {
  const [editing, setEditing] = React.useState(false);
  const [name, setName] = React.useState(workflowName);
  React.useEffect(() => setName(workflowName), [workflowName]);

  const commit = () => {
    setEditing(false);
    if (name.trim()) onRename(name.trim());
    else setName(workflowName);
  };

  return (
    <header className="topbar">
      <div className="brand">
        <div className="brand-mark">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M5 5l7 14 7-14M9 13h6" />
          </svg>
        </div>
        <div>
          <div className="brand-name">KiAgent</div>
          <div className="brand-sub mono">studio · v0.4</div>
        </div>
      </div>

      <nav className="crumbs">
        <span>Workspace</span>
        <span className="crumb-sep">/</span>
        <span>Multi-Agent</span>
        <span className="crumb-sep">/</span>
        {editing ? (
          <input
            autoFocus
            className="field-input mono"
            style={{ padding: "3px 8px", width: 220, fontSize: 12.5 }}
            value={name}
            onChange={(e) => setName(e.target.value)}
            onBlur={commit}
            onKeyDown={(e) => { if (e.key === "Enter") commit(); if (e.key === "Escape") { setName(workflowName); setEditing(false); } }}
          />
        ) : (
          <button className="crumb-edit" onClick={() => setEditing(true)}>
            <span className="dot-active" />
            <span className="crumb-current">{workflowName}</span>
          </button>
        )}
      </nav>

      <div className="spacer" />

      <div className="tabs">
        <button className="tab is-active">Editor</button>
        <button className="tab">Ausführungen</button>
        <button className="tab">Logs</button>
      </div>

      <button className="btn btn-ghost" title="Verlauf"><IcoHistory /></button>
      <button className="btn btn-ghost" title="Mehr"><IcoMore /></button>

      <div className="avatar-stack">
        <div className="avatar avatar-1">MS</div>
        <div className="avatar avatar-2">JK</div>
        <div className="avatar">+2</div>
      </div>

      <button className="btn"><IcoSave /> Speichern <span className="btn-kbd">⌘S</span></button>
      <button className="btn btn-primary" onClick={onRun}>
        <IcoPlay />
        {isRunning ? "Läuft…" : "Workflow ausführen"}
      </button>
    </header>
  );
}

// ─── Sidebar palette ─────────────────────────────────────────────────────
function Sidebar({ onAdd }) {
  const [q, setQ] = React.useState("");
  const filter = q.trim().toLowerCase();

  return (
    <aside className="sidebar">
      <div className="sb-search">
        <IcoSearch />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Knoten suchen…"
        />
        <span className="kbd">/</span>
      </div>
      <div className="sb-scroll">
        {PALETTE_GROUPS.map((group) => {
          const items = group.types.filter((t) => {
            if (!filter) return true;
            const d = NODE_TYPES[t];
            return d.label.toLowerCase().includes(filter) || d.description.toLowerCase().includes(filter);
          });
          if (!items.length) return null;
          return (
            <div className="sb-section" key={group.id}>
              <div className="sb-section-h">
                <span>{group.label}</span>
                <span className="count">{items.length}</span>
              </div>
              {items.map((t) => {
                const d = NODE_TYPES[t];
                const Icon = window[d.icon];
                return (
                  <div
                    key={t}
                    className="node-pill"
                    onClick={() => onAdd(t)}
                    title={d.description}
                  >
                    <div className="ic" style={{ color: d.color }}>
                      <Icon />
                    </div>
                    <div className="lbl">
                      <b>{d.label}</b>
                      <span>{d.description}</span>
                    </div>
                    <span className="grip"><IcoGrip /></span>
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>
    </aside>
  );
}

// ─── Inspector ───────────────────────────────────────────────────────────
function Inspector({ node, onClose, onPatch, onDelete }) {
  const open = !!node;
  const def = node ? NODE_TYPES[node.type] : null;
  const Icon = def ? window[def.icon] : null;
  const [tab, setTab] = React.useState("config");
  React.useEffect(() => { setTab("config"); }, [node?.id]);

  return (
    <aside className={`inspector ${open ? "is-open" : ""}`}>
      {def && (
        <>
          <div className="insp-head">
            <div className="node-icon" style={{ "--node-color": def.color, "--node-h": def.h }}>
              <Icon />
            </div>
            <div className="insp-head-text">
              <b>{node.title || def.label}</b>
              <span>id · {node.id}</span>
            </div>
            <button className="insp-close" onClick={onDelete} title="Knoten löschen (Entf)"><IcoTrash /></button>
            <button className="insp-close" onClick={onClose} title="Schließen"><IcoClose /></button>
          </div>
          <div className="insp-tabs">
            <button className={`insp-tab ${tab === "config" ? "is-active" : ""}`} onClick={() => setTab("config")}>Konfiguration</button>
            <button className={`insp-tab ${tab === "io" ? "is-active" : ""}`} onClick={() => setTab("io")}>I/O</button>
            <button className={`insp-tab ${tab === "settings" ? "is-active" : ""}`} onClick={() => setTab("settings")}>Erweitert</button>
          </div>
          <div className="insp-body">
            {tab === "config" && <ConfigPanel node={node} def={def} onPatch={onPatch} />}
            {tab === "io" && <IOPanel node={node} />}
            {tab === "settings" && <SettingsPanel node={node} onPatch={onPatch} />}
          </div>
        </>
      )}
    </aside>
  );
}

function ConfigPanel({ node, def, onPatch }) {
  if (node.type === "project_manager" || node.type === "architect_collab") {
    return (
      <>
        <Field label="Name">
          <input className="field-input" value={node.title || def.label}
                 onChange={(e) => onPatch({ title: e.target.value })} />
        </Field>
        <Field label="System-Prompt" help="Wird an alle Provider als System-Prompt mitgegeben.">
          <textarea className="field-input" rows={5} defaultValue={
`Du bist Project Manager / Orchestrator für ein Multi-Agent-System.
Erstelle einen Projektplan (3–5 Punkte), entwirf die Architektur
und delegiere an Frontend / Backend Agents.
Nutze pgvector für ähnliche, abgeschlossene Projekte.`} />
        </Field>
        <Field label="Memory-Lookup">
          <Selector value="pgvector · search_memories(limit=2)" />
        </Field>
        <div className="section-title">Provider & Speicher</div>
        <Field label="Aktive Provider"><Selector value="Groq · Gemini · Mistral · OpenRouter (4)" /></Field>
        <Field label="Synthesizer"><Selector value="Gemini 2.0 Flash · Synthesizer" /></Field>
        <Field label="Memory"><Selector value="pgvector · PM-Namespace" /></Field>
        <div className="toggle-row">
          <div><b>Plan speichern</b><span>store_memory('Project Manager', goal, plan)</span></div>
          <div className="switch is-on" />
        </div>
      </>
    );
  }
  if (node.type === "debate") {
    return (
      <>
        <Field label="Topic-Quelle"><Selector value="goal (Original-Eingabe)" /></Field>
        <Field label="Rednerreihenfolge" help="Jeder Sprecher sieht den vorherigen Transcript.">
          <input className="field-input mono" defaultValue="Groq → Gemini → Mistral → OpenRouter" />
        </Field>
        <Field label="Max. Tokens pro Argument">
          <input className="field-input mono" defaultValue="120" />
        </Field>
        <div className="toggle-row">
          <div><b>Judge ausführen</b><span>DebateJudge bewertet anschließend</span></div>
          <div className="switch is-on" />
        </div>
      </>
    );
  }
  if (node.type === "frontend_agent" || node.type === "backend_agent") {
    const isFE = node.type === "frontend_agent";
    return (
      <>
        <Field label="Modell"><Selector value="Groq · llama-3.3-70b-versatile" /></Field>
        <Field label="System-Prompt">
          <textarea className="field-input" rows={4} defaultValue={
isFE
  ? `Du bist Frontend-Coder. Erzeuge React/TypeScript-Code
basierend auf der vorgegebenen Architektur.`
  : `Du bist Backend-Coder. Erzeuge Python/FastAPI-Code
basierend auf der vorgegebenen Architektur.`
          } />
        </Field>
        <Field label="Parallel zu"><Selector value={isFE ? "Backend Agent (asyncio.gather)" : "Frontend Agent (asyncio.gather)"} /></Field>
        <Field label="Kollaboration mit allen Providern"><Selector value="Groq · Gemini · Mistral · OpenRouter" /></Field>
        <Field label="Memory-Namespace">
          <input className="field-input mono" defaultValue={isFE ? "Frontend Agent" : "Backend Agent"} />
        </Field>
      </>
    );
  }
  if (node.type === "groq_provider") {
    return (
      <>
        <Field label="Modell">
          <select className="field-select" defaultValue="llama-3.3-70b-versatile">
            <option>llama-3.1-8b-instant</option>
            <option value="llama-3.3-70b-versatile">llama-3.3-70b-versatile</option>
            <option>llama-3.3-8b-versatile</option>
          </select>
        </Field>
        <Field label="API-Key (env)"><input className="field-input mono" defaultValue="GROQ_API_KEY" /></Field>
        <Field label="Max. Retry"><input className="field-input mono" defaultValue="3" /></Field>
        <Field label="Status"><Selector value="immer aktiv (always-on)" /></Field>
      </>
    );
  }
  if (node.type === "gemini_provider" || node.type === "mistral_provider" ||
      node.type === "openrouter_provider" || node.type === "reasoning_provider") {
    const envName = {
      gemini_provider: "GOOGLE_API_KEY",
      mistral_provider: "MISTRAL_API_KEY",
      openrouter_provider: "OPENROUTER_API_KEY",
      reasoning_provider: "OPENROUTER_REASONING_API_KEY",
    }[node.type];
    const modelName = {
      gemini_provider: "gemini-2.0-flash",
      mistral_provider: "mistral-small-latest",
      openrouter_provider: "baidu/cobuddy:free",
      reasoning_provider: "openai/gpt-4o-mini:reasoning",
    }[node.type];
    return (
      <>
        <Field label="Modell"><input className="field-input mono" defaultValue={modelName} /></Field>
        <Field label="API-Key (env)"><input className="field-input mono" defaultValue={envName} /></Field>
        <Field label="Status" help="Wird aktiviert, sobald der env-Key gesetzt ist.">
          <Selector value="aktiv · key vorhanden" />
        </Field>
        <Field label="Max. Tokens (Debatte)"><input className="field-input mono" defaultValue="120" /></Field>
      </>
    );
  }
  if (node.type === "synthesizer") {
    return (
      <>
        <Field label="Modell"><input className="field-input mono" defaultValue="gemini-2.0-flash" /></Field>
        <Field label="API-Key (env)"><input className="field-input mono" defaultValue="GOOGLE_API_KEY" /></Field>
        <Field label="Strategie" help="Wie die Outputs der Provider kombiniert werden.">
          <select className="field-select" defaultValue="merge">
            <option value="merge">Merge & dedupe</option>
            <option>Best-of</option>
            <option>Vote</option>
          </select>
        </Field>
      </>
    );
  }
  if (node.type === "pgvector_memory") {
    return (
      <>
        <Field label="Adapter"><Selector value="memory_manager.py · pgvector" /></Field>
        <Field label="DSN"><input className="field-input mono" defaultValue="postgresql://kiagent:***@db:5432/agents" /></Field>
        <Field label="Embedding-Modell"><Selector value="text-embedding-3-small" /></Field>
        <Field label="Genutzt von" help="Welche Phasen lesen / schreiben.">
          <Selector value="PM · Architect · FE · BE · Self Improver" />
        </Field>
      </>
    );
  }
  if (node.type === "task_received" || node.type === "chat_followup") {
    const isChat = node.type === "chat_followup";
    return (
      <>
        <Field label="Methode"><input className="field-input mono" defaultValue="POST" /></Field>
        <Field label="Pfad"><input className="field-input mono" defaultValue={isChat ? "/api/chat" : "/api/run"} /></Field>
        <Field label="Body-Schema">
          <pre className="field-input mono" style={{ whiteSpace: "pre-wrap", margin: 0, fontSize: 11.5, lineHeight: 1.55 }}>
{isChat
  ? `{
  "message": str,
  "context": str = "",
  "language": "de" | "en" = "de"
}`
  : `{
  "goal": str,
  "language": "de" | "en" = "de"
}`}
          </pre>
        </Field>
        <div className="toggle-row">
          <div><b>CORS</b><span>localhost:3000 erlaubt</span></div>
          <div className="switch is-on" />
        </div>
      </>
    );
  }
  if (node.type === "ws_broadcast") {
    return (
      <>
        <Field label="Pfad"><input className="field-input mono" defaultValue="/ws" /></Field>
        <Field label="Manager"><Selector value="ConnectionManager · websocket/manager.py" /></Field>
        <Field label="Payload-Schema">
          <pre className="field-input mono" style={{ whiteSpace: "pre-wrap", margin: 0, fontSize: 11.5, lineHeight: 1.55 }}>
{`{
  "agent": str,   // z.B. "Groq · Architektur"
  "message": str  // markdown
}`}
          </pre>
        </Field>
        <Field label="Aktive Clients"><Selector value="2 verbunden" /></Field>
      </>
    );
  }
  if (node.type === "self_improver" || node.type === "judge" || node.type === "review_collab") {
    return (
      <>
        <Field label="Modell"><Selector value="Groq · llama-3.3-70b-versatile" /></Field>
        <Field label="System-Prompt">
          <textarea className="field-input" rows={4} defaultValue={
node.type === "judge"
  ? `Du bist Architecture Judge. Bewerte die Debatte und
liefere ein klares Verdict mit Begründung.`
  : node.type === "self_improver"
  ? `Du bist Self-Improver. Bewerte die Outputs auf
Korrektheit, Vollständigkeit und Code-Qualität.`
  : `Du bist Reviewer. Finde Bugs, Sicherheitsprobleme und
schlage konkrete Verbesserungen am Code vor.`} />
        </Field>
        {node.type === "self_improver" && (
          <Field label="Schreibt nach"><Selector value="pgvector · learnings" /></Field>
        )}
        {node.type === "review_collab" && (
          <Field label="Provider"><Selector value="alle aktiven (4) + Synthesizer" /></Field>
        )}
      </>
    );
  }
  // Fallback
  return (
    <>
      <Field label="Name"><input className="field-input" defaultValue={node.title || def.label} /></Field>
      <Field label="Beschreibung"><textarea className="field-input" rows={3} defaultValue={def.description} /></Field>
    </>
  );
}

function IOPanel({ node }) {
  return (
    <>
      <div className="section-title">Letzte Ausführung</div>
      <Field label="Input">
        <pre className="field-input mono" style={{ whiteSpace: "pre-wrap", margin: 0, fontSize: 11.5, lineHeight: 1.55 }}>
{`{
  "goal": "Build a REST API for a\\ntodo app with auth",
  "language": "de"
}`}
        </pre>
      </Field>
      <Field label="Output (broadcast via /ws)">
        <pre className="field-input mono" style={{ whiteSpace: "pre-wrap", margin: 0, fontSize: 11.5, lineHeight: 1.55, color: "var(--ok)" }}>
{`{
  "agent": "Synthesizer",
  "message": "**Architektur**\\n\\nFastAPI + SQLModel +\\nJWT-Auth …",
  "tokens": 1248,
  "duration_ms": 4820
}`}
        </pre>
      </Field>
      <Field label="Metriken">
        <div className="field-input mono">4.82 s · 1248 tokens · 4 provider</div>
      </Field>
    </>
  );
}

function SettingsPanel({ node, onPatch }) {
  return (
    <>
      <div className="toggle-row">
        <div><b>Bei Fehler weiter</b><span>Workflow nicht abbrechen</span></div>
        <div className="switch" />
      </div>
      <div className="toggle-row">
        <div><b>Wiederholungen</b><span>Bis zu 3 Versuche</span></div>
        <div className="switch is-on" />
      </div>
      <div className="toggle-row">
        <div><b>Caching aktivieren</b><span>Identische Inputs nicht erneut ausführen</span></div>
        <div className="switch" />
      </div>
      <div className="section-title">Notizen</div>
      <Field label="">
        <textarea className="field-input" rows={3} placeholder="Notizen für dein Team…" />
      </Field>
    </>
  );
}

function Field({ label, help, children }) {
  return (
    <div className="field">
      {label && <div className="field-label"><span>{label}</span></div>}
      {children}
      {help && <div className="field-help">{help}</div>}
    </div>
  );
}

function Selector({ value }) {
  return (
    <div className="field-select" style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <span style={{ width: 6, height: 6, borderRadius: 99, background: "var(--ok)", flexShrink: 0 }} />
      <span style={{ flex: 1 }}>{value}</span>
    </div>
  );
}

function SliderField({ defaultValue = 0.5 }) {
  const [v, setV] = React.useState(defaultValue);
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
      <input type="range" min="0" max="1" step="0.01" value={v}
             onChange={(e) => setV(parseFloat(e.target.value))}
             style={{ flex: 1, accentColor: "var(--accent)" }} />
      <span className="mono" style={{ fontSize: 12, color: "var(--fg-2)", width: 36, textAlign: "right" }}>
        {v.toFixed(2)}
      </span>
    </div>
  );
}

Object.assign(window, { Topbar, Sidebar, Inspector });
